/**
 * Created by zhengjin on 2017/1/9.
 *
 * Include common utils and functions.
 */

var v1MockWeatherData = require('./mock_weather_res_data_v1');
var v2MockWeatherData = require('./mock_weather_res_data_v2');

module.exports = {
    v1: v1MockWeatherData,
    v2: v2MockWeatherData
};
