<template>
  <span>Message: {{ message }}</span>
</template>

<script>
export default {
  props: ['message']
}
</script>
