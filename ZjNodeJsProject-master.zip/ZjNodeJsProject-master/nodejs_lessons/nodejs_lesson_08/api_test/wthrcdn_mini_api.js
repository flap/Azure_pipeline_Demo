/**
 * Created by zhengjin on 2016/12/9.
 *
 * Verify weather data api from http://wthrcdn.etouch.cn/weather_mini?citykey={value}
 */

// TODO: 2016.12.9

if (require.main === module) {
    console.log(__filename, 'DONE.');
}
