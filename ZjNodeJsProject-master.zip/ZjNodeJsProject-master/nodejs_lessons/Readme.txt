Refer to https://github.com/alsotang/node-lessons/

For more material, access https://cnodejs.org/getstart

Install node package by using image from --registry=https://registry.npm.taobao.org
